<div id="footer">				
<nav class="navbar navbar-inverse navbar-static-bottom" role="navigation">
    <ul class="nav navbar-nav navbar-left">
        <li><a href="mailto:altaf.aali@gmail.com">(C)2017 Altaf Aali <i class="fa fa-envelope fa-fw"></i>altaf.aali@gmail.com</a></li>
    </ul>
</nav>
</div>