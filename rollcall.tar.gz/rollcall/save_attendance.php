<?php                                            
$action = $_GET ['action'];
$student_id = $_GET ['student_id'];
$session = $_GET ['session'];
$status = $_GET ['status'];
$servername = "localhost";
$username = "root";
$password = "Vs6TirDtRj";
$database = "rollcall";
$conn = mysql_connect($servername, $username, $password);            
if (!$conn)
	return;
mysql_select_db($database);

if ($action == 'set')
{
	$query = 'INSERT into attendance (student_id,date,status) values ("'.$student_id.'","'.$session.'","'.$status.'") ON DUPLICATE KEY UPDATE status="'.$status.'";';
	//echo $query;
	$result = mysql_query($query);	
}
?>