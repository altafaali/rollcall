SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

CREATE DATABASE IF NOT EXISTS rollcall;

USE rollcall;

CREATE TABLE IF NOT EXISTS classrooms (
  grade_section varchar(250) NOT NULL,
  room varchar(250) DEFAULT NULL,
  PRIMARY KEY (grade_section)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS students (
  student_id varchar(250) NOT NULL,
  grade_section varchar(250) NOT NULL,
  first_name varchar(250),
  last_name varchar(250),
  PRIMARY KEY (student_id)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS attendance (	
  student_id varchar(250) NOT NULL,
  grade_section varchar(250) NOT NULL,
  date DATETIME NOT NULL,					/* the data the attendance was taken */
  status varchar(1),						/* P= present, A=absent, T=tardy, E=Excused */
  PRIMARY KEY (student_id,date)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;




