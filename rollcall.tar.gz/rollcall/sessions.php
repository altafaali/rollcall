<ul class="nav navbar-defaullt nav-tabs">
  <li role="presentation" class="active"><a href="#">Update or add session for <?php echo $_GET ['classroom']; ?></a></li>
  <li role="presentation"><a href="index.php">Back to classroom selection</a></li>
</ul>

<table id="sessions" class="display" cellspacing="0" width="100%">
   <thead>
        <tr>
            <th></th>
        </tr>
    </thead>
<!--<tfoot>
        <tr>
            <th>Grade/Section</th>
            <th>Room</th>
        </tr>
    </tfoot> -->    
    <tbody>
        <tr class="odd gradeX">
            <td>Add</td>
        </tr>
        <?php                                            
        $grade_section = $_GET ['classroom'];
        $query = 'SELECT distinct date from attendance where grade_section="'.$grade_section.'"';
        $result = mysql_query($query);
        $rows = mysql_num_rows($result);
        for($j = 0; $j < $rows; ++$j)
        {
            $date = mysql_result($result, $j, 'grade_section');
            echo '<tr class="odd gradeX">';  
            //$style='style="background:#c9ff99;"';
            echo '<td '.$style.'>'.$date.'</td>';
            echo '</tr>';
        }
        ?>                                                                  
    </tbody>
</table>

<script type="text/javascript">
$(document).ready(function() {
    var table = $('#sessions').DataTable({
    responsive: true,
    paging: false,
    searching: false,
    ordering: false,
    width: '100%'
	} );
 
    $('#sessions tbody').on( 'click', 'tr', function () {
        if ( $(this).hasClass('selected') ) {
            $(this).removeClass('selected');
        }
        else {
            table.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
            var rowDataString =  (table.row( this ).data()).toString();
            $(this).removeClass('selected');
            //alert (rowDataString);
            var classroom = "<?php echo $_GET ['classroom']; ?>";
            window.location = 'index.php?page=attendance&session='+rowDataString+'&classroom='+classroom;
            //$.mobile.changePage('index.php?page=attendance&session='+rowDataString+'&classroom='+classroom,{transition:"slide"});
        }
    } ); 
} );

</script>
