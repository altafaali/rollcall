<header>
<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
    <div class="navbar-header">
        <a class="navbar-brand">RollCall Attendance System</a>
    </div>
</nav> 
</header>   
