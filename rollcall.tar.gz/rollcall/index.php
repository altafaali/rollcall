<!-- This is the master page and controller -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>RollCall</title>

    <!-- Boostrap 3 CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<!-- Optional theme -->
	<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">-->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/cerulean/bootstrap.min.css">
	<!-- DataTables CSS for bootstrap 3 -->
	<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap.min.css" >
	<!-- datatables CSS for jquery -->
	<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" >	
	<!-- font awesome CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" >	
	<!-- Jquery mobile -->
	<link rel="stylesheet" href="http://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css" />		

	<!-- override defaults -->
	<style>
	body {   font-size: 20px; line-height: 2;}
	.footer-bottom {
		background: #E3E3E3;
		border-top: 1px solid #DDDDDD;
		padding-top: 10px;
		padding-bottom: 10px;
	}
	.footer-bottom p.pull-left {
		padding-top: 6px;
	}	
	</style>

 	<!-- scripts -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script> 	
 	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
 	<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js" </script>
	<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js" </script>	

<!--<script type="text/javascript">
	$(document).on("mobileinit", function(){
	$.mobile.defaultPageTransition = 'slide';
	});
</script>-->

	<script src="http://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>

</head>	

<body>

	<div id="wrapper">
	<?php
	include("header.php");
	?>
		<div class="container-fluid">
		<?php

			/* connect to database */
            $servername = "localhost";
            $username = "root";
            $password = "Vs6TirDtRj";
            $database = "rollcall";
			$conn = mysql_connect($servername, $username, $password);            
			if (!$conn)
			{
				include ("404.php");
			}
			else
			{
				mysql_select_db($database);
				$page = $_GET['page'];
				//echo $page;
				if (strlen($page)==0)
				{
					include("classrooms.php");
				}       
	    		else
	    		{
	    			include("$page.php");        		
				}
				mysql_close(); /* disconnect from database */
			}
		?>
	    </div>
	    <!-- container -->
	<?php
	include("footer.php");
	?>
	</div>
 	<!-- wrapper -->


</body>

</html>

