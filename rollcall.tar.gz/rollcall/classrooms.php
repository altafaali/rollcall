<ul class="nav nav-tabs">
  <li role="presentation" class="active"><a href="#">Select classroom</a></li>
  <li role="presentation"><a href="index.php?page=reports">View reports</a></li>
</ul>

<table id="classrooms" class="display" cellspacing="0" width="100%">
    <thead>
        <tr>
            <th>Grade/Section</th>
            <th>Room</th>
        </tr>
    </thead>
<!--    <tfoot>
        <tr>
            <th>Grade/Section</th>
            <th>Room</th>
        </tr>
    </tfoot> -->
    <tbody>
        <?php                                            
        $query = "SELECT grade_section,room FROM classrooms";
        $result = mysql_query($query);
        $rows = mysql_num_rows($result);
        for($j = 0; $j < $rows; ++$j)
        {
            $grade_section = mysql_result($result, $j, 'grade_section');
            $room = mysql_result($result, $j, 'room');
            echo '<tr class="odd gradeX">';  
            //$style='style="background:#c9ff99;"';
            echo '<td '.$style.'>'.$grade_section.'</td>';
            echo '<td '.$style.'>'.$room.'</td>';
            echo '</tr>';
        }
        ?>                                                                  
    </tbody>
</table>

<script type="text/javascript">
$(document).ready(function() {
    var table = $('#classrooms').DataTable({
    responsive: true,
    paging: false,
    width: '100%'
	} );


 
    $('#classrooms tbody').on( 'click', 'tr', function () {
        if ( $(this).hasClass('selected') ) {
            $(this).removeClass('selected');
        }
        else {
            table.$('tr.selected').removeClass('selected');
            $(this).addClass('selected');
            var rowDataString =  (table.row( this ).data()).toString();
            $(this).removeClass('selected');
            var tokens = rowDataString.split (",");            
            //alert ('+++'+tokens[0]+'+++');
            document.location.href = 'index.php?page=sessions&classroom='+tokens[0];
            //$.mobile.changePage('index.php?page=sessions&classroom='+tokens[0],{transition:"slide"});
            //window.reload (true);
        }
    } ); 
} );

</script>

