delete from classrooms;
delete from students;
delete from attendance;

INSERT INTO classrooms (grade_section,room) VALUES
("KJ", "101"),
("KS", "102"),
("KL", "103"),
("1S", "105"),
("1D", "106");

INSERT INTO students (student_id,grade_section,first_name,last_name) VALUES
("210", "KJ","Tom","Hardy"),
("213", "KJ","Arnold","S"),
("311", "KJ","Keanu","R"),
("443", "KS","Ray","Romano"),
("232", "KS","E","Mitchell"),
("471", "KL","Alex","Cooper"),
("981", "KL","Toby","M"),
("444", "1S","B","Cumbertach"),
("333", "1D","J","Franco");
