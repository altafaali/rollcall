<center> 
<p>
<p>
Oops....something bad has happened ...
<p>
Rest assured. we are working on to fix it ASAP
<p>
In the meantime <a href="http://www.flipboard.com">Go ahead and read the news </a>
<p>
<p>