<ul class="nav navbar-defaullt nav-tabs">
  <?php 
  	$session = $_GET ['session'];
  	$date == '';
  	if ($session == "Add")
  	{
  		$date = date ("Y-m-d");
  		//echo $date;
  	}
  ?>  
  <li role="presentation" class="active"><a href="#"><?php echo $date ?> Attendance for <?php echo $_GET ['classroom']; ?></a></li>
  <li role="presentation">
  <?php echo '<a href="index.php?page=sessions&classroom='.$_GET ['classroom'].'">Back to session selection</a>'; ?>
  </li>
</ul>

<table id="attendance" class="display" cellspacing="0" width="100%">
    <thead>
        <tr>
            <th>Name</th>
            <th>P</th>
            <th>T</th> 
            <th>E</th>
            <th>A</th>
        </tr>
    </thead>
<!--    <tfoot>
        <tr>
            <th>Grade/Section</th>
            <th>Room</th>
        </tr>
    </tfoot> -->
    <tbody>
        <?php                
        $grade_section = $_GET ['classroom'];                            
        //echo '******'.$grade_section.'******';
        $query = 'SELECT student_id,first_name,last_name from students where grade_section="'.$grade_section.'"';
        //echo $query;
        $result = mysql_query($query);
        $rows = mysql_num_rows($result);
        for($j = 0; $j < $rows; ++$j)
        {
            $first_name = mysql_result($result, $j, 'first_name');
            $last_name = mysql_result($result, $j, 'last_name');
            $student_id = mysql_result($result, $j, 'student_id');
            echo '<tr class="odd gradeX">';  
            //$style='style="background:#c9ff99;"';
            $style = '';
            $name = $first_name.' '.$last_name;
            echo '<td '.$style.'>'.$name.'</td>';
            //$checked = 'checked="true"';
            $checked='';
            $checkbox_label = '';
            
            $checkbox_name = 'P'.$student_id;
            echo '<td '.$style.'> <input type="checkbox" id="'.$checkbox_name.'" '.$checked.' onchange="att_changed(this);">  '.$checkbox_label.'</td>';
            $checkbox_name = 'T'.$student_id;
            echo '<td '.$style.'> <input type="checkbox" id="'.$checkbox_name.'" '.$checked.' onchange="att_changed(this);">  '.$checkbox_label.'</td>';
            $checkbox_name = 'E'.$student_id;
            echo '<td '.$style.'> <input type="checkbox" id="'.$checkbox_name.'" '.$checked.' onchange="att_changed(this);">  '.$checkbox_label.'</td>';
            $checkbox_name = 'A'.$student_id;
            echo '<td '.$style.'> <input type="checkbox" id="'.$checkbox_name.'" '.$checked.' onchange="att_changed(this);">  '.$checkbox_label.'</td>';
            echo '</tr>';
        }
        ?>                                                                  
    </tbody>
</table>

<script type="text/javascript">
$(document).ready(function() {
    var table = $('#attendance').DataTable({
    responsive: true,
    paging: false,
    ordering: false,
    width: '100%'
	} );    
} );

    function att_changed (e)
    {
        var data = e.id.toString();


        //alert (e.checked);
        // first letter of name is attendnace status
        var status = data.substring(0,1);
        var student_id = data.substring (1);
        var session = "<?php echo $date; ?>";
        //alert (session);
        //alert (status);
        //alert (student_id);
        //alert (e.checked);
        if (e.checked == true)
        {
            var present_checkbox_name = 'P'+student_id;
            var tardy_checkbox_name = 'T'+student_id;
            var absent_checkbox_name = 'A'+student_id;
            var excused_checkbox_name ='E'+student_id;
            // uncheck all other boxes
            if (status == 'P')
            {
                document.getElementById(tardy_checkbox_name).checked = false;
                document.getElementById(absent_checkbox_name).checked = false;
                document.getElementById(excused_checkbox_name).checked = false;
            }
            else
            if (status == 'A')
            {
                document.getElementById(tardy_checkbox_name).checked = false;                
                document.getElementById(present_checkbox_name).checked = false;
                document.getElementById(excused_checkbox_name).checked = false;            
            }
            else
            if (status == 'E')
            {
                document.getElementById(tardy_checkbox_name).checked = false;                
                document.getElementById(present_checkbox_name).checked = false;
                document.getElementById(absent_checkbox_name).checked = false;                            
            }
            else
            {
                document.getElementById(present_checkbox_name).checked = false;
                document.getElementById(absent_checkbox_name).checked = false;                            
                document.getElementById(excused_checkbox_name).checked = false;            
            }

            // now make a ajax call to add or update attendance entry
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) 
            {
                 //alert (this.responseText);
                 if (this.responseText=='error')
                    alert ('error');
            }};
            xhttp.open('GET', 'save_attendance.php?action=set&student_id='+student_id+'&session='+session+'&status='+status, true);
            xhttp.send();
        }
        else
        {
            // make an ajax call to delete the attendance entry
        }
    }


</script>
